import java.io.FileNotFoundException;
import java.util.List;

import javax.swing.JFrame;

public class Main {
	public static void main(String[] args) throws FileNotFoundException {
		// Skapa en graf utan att ange startvertex
		Graph g = new Graph();
		// Läs in vertexar och kanter från filer
		g.readVertexFile("/Users/mac/Downloads/760_tatorter.csv");
		g.readEdgeFile("/Users/mac/Downloads/edges_760_tatorter.csv");

		// Sätt startvertex när vertexarna har laddats
		g.setStartVertex("Gävle");

		
        MapPanel mapPanel = new MapPanel(g);

        JFrame frame = new JFrame("Map Panel Example");
 
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().add(mapPanel);
        frame.setSize(800, 600);
        frame.setVisible(true);
		
		
		// Testa att hitta den kortaste vägen mellan två orter
		List<String> path = g.findShortestPath("Gävle", "Uppsala");
		System.out.println("Shortest path from Gävle to Valbo: " + String.join(" -> ", path));

		// Sätt målvertex och hämta den
		Vertex targetVertex = g.getVertices().stream().filter(v -> v.getName().equals("Valbo")).findFirst()
				.orElse(null);
		if (targetVertex != null) {
			g.setTargetVertex(targetVertex);
			System.out.println("Target vertex set to: " + g.getTargetVertex().getName());
		} else {
			System.out.println("Valbo not found in the graph.");
		}

//		// Skriv ut alla vertexar i grafen
//		System.out.println("All vertices in the graph:");
//		for (Vertex vertex : g.getVertices()) {
//			System.out.println(vertex.getName() + " (Population: " + vertex.getPopulation() + ")");
//		}
//	}
	}
}
